const quizForm = document.getElementById('quiz-form');
const resultsContainer = document.getElementById('results');
const progressBar = document.getElementById('progress-bar');
const questionsCount = document.querySelectorAll('.question').length;
let currentQuestionIndex = 0;

quizForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const q1Answer = document.querySelector('input[name="q1"]:checked');
  const q2Answer = document.querySelector('input[name="q2"]:checked'); // Corrected selector for q2Answer

  // Now you can continue with your logic for handling the form submission, checking answers, etc.
});
